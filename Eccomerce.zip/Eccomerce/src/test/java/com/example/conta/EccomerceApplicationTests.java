package com.example.conta;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EccomerceApplicationTests {

	@Test
	void contextLoads() {
	}

}
