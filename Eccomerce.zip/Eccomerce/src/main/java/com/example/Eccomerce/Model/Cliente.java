package com.example.Eccomerce.Model;

public class Cliente {

}
